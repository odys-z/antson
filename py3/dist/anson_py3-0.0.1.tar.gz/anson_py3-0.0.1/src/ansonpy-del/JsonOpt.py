
class JsonOopt:
    quotekey = True;
    
    def quoteK(self):
        return self.quotekey;