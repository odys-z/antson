'''
Created on 28 Oct 2019

Data types for test cases.

@author: odys-z@github.com
'''

from ansonpy.anson import Anson

class AnsT1(Anson):
    ver = "0.2" # type: str 
    
    m = None # type: AnsM1 
